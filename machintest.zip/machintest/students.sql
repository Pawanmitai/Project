-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2021 at 01:47 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `students`
--

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE `enrollment` (
  `id` int(11) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pin` bigint(30) NOT NULL,
  `phone` bigint(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `marks` int(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`id`, `studentname`, `fathername`, `dob`, `address`, `city`, `state`, `pin`, `phone`, `email`, `class`, `marks`, `created_at`) VALUES
(1, 'Pawan hence', 'Mitai Vishwakarma', '2021-05-26', 'Noida', 'Noida', 'Uttar Pradesh', 234242, 9792456245, 'pawanbharat@gmail.com', '5th', 56, '2021-05-25 10:13:13'),
(2, 'Pawan', 'Mitai Vishwakarma', '2021-05-26', 'Noida', 'Noida', 'Uttar Pradesh', 234242, 9792456245, 'pawan@gmail.com', '5th', 56, '2021-05-25 08:51:10'),
(3, 'Jump', 'jump', '2021-05-12', 'jump', 'jupmp', 'uujj', 34234, 7905129037, 'pawan@gmai.com', '5th', 555, '2021-05-25 09:48:10'),
(4, 'Pawan vishwakarma', 'Mitai Vishwakarma', '2021-05-26', 'Noida', 'Noida', 'Uttar Pradesh', 234242, 9792456245, 'pawan@gmail.com', '5th', 56, '2021-05-25 10:08:49'),
(5, 'Henry', 'Mitai Vishwakarma', '2021-05-26', 'Noida', 'Noida', 'Uttar Pradesh', 234242, 9792456245, 'pawan@gmail.com', '5th', 56, '2021-05-25 11:11:35'),
(6, 'good', 'good', '2021-05-06', 'Noida', 'kankput', 'Uttar Pradesh', 234234, 9792456325, 'admin@gmail.com', '10th', 34, '2021-05-25 11:26:57'),
(7, 'Pawan', 'jak', '2021-05-19', 'Noida', 'kankput', 'asdf', 234234, 9792456325, 'admin@gmail.com', '9th', 34, '2021-05-25 11:40:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enrollment`
--
ALTER TABLE `enrollment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
