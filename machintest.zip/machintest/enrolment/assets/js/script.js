jQuery(document).ready(function(){
	jQuery('#data').DataTable();
});



