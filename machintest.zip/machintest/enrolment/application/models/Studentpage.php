<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Studentpage extends CI_MODEL {

	
	public function addstudent($data)
	{

		$this->db->insert('enrollment',$data);
		return 1;
	}

	public function view($limit,$offset)
	{
		
		$this->db->limit($limit,$offset);
		$query= $this->db->get('enrollment')->result_array();
		return $query;
		
	}


	public function recordview($id)
	{
		$this->db->where('id',$id);
		return $this->db->get('enrollment')->row_array();
		
	}


	public function countrows()
	{
		return $this->db->get('enrollment')->num_rows();
	}

	public function edit($data,$id)
	{
		$this->db->where('id',$id);
		$this->db->update('enrollment',$data);
		return 1;
	}

	public function delete($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('enrollment');
		return 1;
	}

public function view_all($id)
	{
		$this->db->where('id',$id);
		return $this->db->get('enrollment')->row_array();
		
	}

}