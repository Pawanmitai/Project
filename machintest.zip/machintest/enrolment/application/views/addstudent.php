<?php include('includes/header.php');?>
<h1 class="text-primary">Add New Student!</small></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
     <li class="breadcrumb-item" aria-current="page"><a href="<?php echo base_url();?>">Dashboard </a></li>
     <li class="breadcrumb-item active" aria-current="page">Add Student</li>
  </ol>
</nav>

<div class="row">
	<div class="col-sm-3"></div>
<div class="col-sm-6">
	<?php if($this->session->flashdata('notsubmitted'))
	{ ?>
	<div class="alert alert-warning">
		<?php echo $this->session->flashdata('notsubmitted'); ?>
	</div>
<?php } ?>
		
	<form enctype="multipart/form-data" method="POST" action="<?php echo base_url('student/addnewstudent');?>">
		<div class="form-group">
		    <label for="name">Student Name</label>
		    <input name="studentname" type="text" class="form-control" pattern="[a-zA-Z ]{3,30}" value="" required="">
	  	</div>
	  	<div class="form-group">
		    <label for="eamil">Email</label>
		    <input name="email" type="text" class="form-control" pattern="^[A-Z0-9._%+-]{3,30}+@[A-Z0-9.-]{2,10}+\.[A-Z]{2,4}$"  required="">
		   
	  	</div>
	  	<div class="form-group">
		    <label for="pcontact">Phone</label>
		    <input name="phone" type="text" class="form-control" id="pcontact" pattern="[0-9]{10}"  required="">
		     
	  	</div>

	  	<div class="form-group">
		    <label for="roll">DOB</label>
		    <input name="dob" type="date" value="" class="form-control" pattern=""  required="">
	  	</div>
	  	<div class="form-group">
		    <label for="roll">Father Name</label>
		    <input name="fathername" type="text" value="" class="form-control" pattern="[a-zA-Z ]{2,30}"  required="">
	  	</div>
	  	<div class="form-group">
		    <label for="address">Address</label>
		    <input name="address" type="text" pattern="[a-zA-Z0-9_./\ ]" class="form-control" id="address" required="">
	  	</div>
	  		<div class="form-group">
		    <label for="address">City</label>
		    <input name="city" type="text" value="" class="form-control" id="address" required="">
	  	</div>
	  		<div class="form-group">
		    <label for="address">State</label>
		    <input name="state" type="text" pattern="[a-zA-Z ]{3,30}" class="form-control" id="address" required="">
	  	</div>
	  		<div class="form-group">
		    <label for="address">PIN</label>
		    <input name="pin" type="text" pattern="[0-9]{6}" class="form-control"  required="">
	  	</div>
	  	<div class="form-group">
		    <label for="class">Class Opted</label>
		    <select name="class" required aria-required="true" class="form-control" >
		    	<option value="">Choose</option>
		    	<option value="5th">5th</option>
		    	<option value="6th">6th</option>
		    	<option value="7th">7th</option>
		    	<option value="8th">8th</option>
		    	<option value="9th">9th</option>
		    	<option value="10th">10th</option>
		    </select>
	  	</div>
	  	<div class="form-group">
		    <label for="pcontact">Marks</label>
		    <input name="marks" type="text" class="form-control"  pattern="[0-9.%]{1,6}"  required="">
	  	</div>
	  	
	  	<div class="form-group text-center">
		    <input name="submit" type="submit" class="btn btn-danger" value="Add Student">
	  	</div>
	 </form>
</div>
</div>