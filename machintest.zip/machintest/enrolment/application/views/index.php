<?php include('includes/header.php');?>
  <body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
 <!--  <a class="navbar-brand" href="index.php"><i class="fas fa-chart-line fa-3x"></i></a> -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="navbar-collapse collapse justify-content-end" id="navbarSupportedContent">
   
    <ul class="nav navbar-nav ">
    
      <li class="nav-item"><a class="nav-link" href="index.php?page=user-profile"><i class="fa fa-user"></i> Enrollment</a></li>
      
    </ul>
  </div>
</nav>
<br>
    <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="list-group">
              <a href="" class="list-group-item list-group-item-action active">
               Enrollment App
              </a>
              <a href="<?php echo base_url('Student/addnewstudent');?>" class="list-group-item list-group-item-action">New Student</a>
            </div>
          </div>
          <div class="col-md-9">
             <div class="content">
              

              
              <h1 class="text-primary"><small class="text-warning"> All Students List!</small></h1>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                   <li class="breadcrumb-item" aria-current="page"><a href="">Dashboard </a></li>
                   <li class="breadcrumb-item active" aria-current="page">All Students</li>
                </ol>
              </nav>

              <?php if($this->session->flashdata('record')) {?>
               <div class="alert alert-success">
                   <?php echo $this->session->flashdata('record');?>
                </div>
                  <?php } ?>
              <table class="table  table-striped table-hover table-bordered">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">SL</th>
                    <th scope="col">Student Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Class</th>
                    <th scope="col">Marks</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                   // href="'.base_url('student/view_all').'?id='.$result['id'].'"
                    foreach ($students as $key => $result) {
                      
                    ?>
                    <tr>

                      <?php 
                      echo '<td class="record_id">'.$result['id'].'</td>
                        <td >'.ucwords($result['studentname']).'</td>
                        <td>'.$result['email'].'</td>
                        <td>'.ucwords($result['phone']).'</td>
                        <td>'.$result['class'].'</td>
                        <td>'.$result['marks'].'</td>
                        <td>
                        <a class="view_btn btn btn-xs btn-primary"  data-toggle="modal" data-target="#recordmodel">
  View
</a>
                          <a class="btn btn-xs btn-warning" href="'.base_url('student/edit').'?id='.$result['id'].'">Edit</a>

                           &nbsp; <a class="btn btn-xs btn-danger" onclick="javascript:confirmationDelete($(this));return false;" href="'.base_url('student/deleterecord').'?id='.$result['id'].'">
                           Delete</a></td>';?>

                    </tr>  
                   <?php } ?>

                  
                </tbody>
              </table>
                 Pages&nbsp;&nbsp;::  <?php   echo $this->pagination->create_links();?>
              <script type="text/javascript">
                function confirmationDelete(anchor)
              {
                 var conf = confirm('Are you sure want to delete this record?');
                 if(conf)
                    window.location=anchor.attr("href");
              }
              </script>
             </div>
        </div>
        </div>  
    </div>
    <!-- ------------------------------- -->
<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="recordmodel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="record_view">
          
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>

  
    <!-- --------------------------------- -->
   
   <script type="text/javascript">
      $(document).ready(function(){

      $('.view_btn').click(function(e)
      {
            e.preventDefault();
           var record= $(this).closest('tr').find('.record_id').text();

           //alert(record);

          $.ajax(
            {
              type:"POST",
              url:"<?php echo base_url('student/singlerecord');?>",
              data:{id:record},
              success: function (result) {
               var data=$.parseJSON(result);
              // $('#record_view').append(data.id);
                
                  $('#record_view').html("<div class='row'><div class='col-sm-4'>Student Name</div><div class='col-sm-4'>" + data.studentname + "</div></div><div class='row'><div class='col-sm-4'>Email</div><div class='col-sm-4'>" + data.email + "</div></div><div class='row'><div class='col-sm-4'>Phone</div><div class='col-sm-4'>" + data.phone + "</div></div><div class='row'><div class='col-sm-4'>DOB</div><div class='col-sm-4'>" + data.dob + "</div></div><div class='row'><div class='col-sm-4'>Father Name</div><div class='col-sm-4'>" + data.fathername + "</div></div><div class='row'><div class='col-sm-4'>Address</div><div class='col-sm-4'>" + data.address + "</div></div><div class='row'><div class='col-sm-4'>City</div><div class='col-sm-4'>" + data.city + "</div></div><div class='row'><div class='col-sm-4'>State</div><div class='col-sm-4'>" + data.state + "</div></div><div class='row'><div class='col-sm-4'>PIN</div><div class='col-sm-4'>" + data.pin + "</div></div><div class='row'><div class='col-sm-4'>Class</div><div class='col-sm-4'>" + data.class + "</div></div><div class='row'><div class='col-sm-4'>Marks</div><div class='col-sm-4'>" + data.marks + "</div></div>");
                  $('#recordmodel').model('show');
                  
               }


            });




      });


    }); 
  </script>
    <div class="clearfix"></div>
   <?php include('includes/footer.php');?>


  






