<?php include('includes/header.php');?>
<h1 class="text-primary">Student!</small></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
     <li class="breadcrumb-item" aria-current="page"><a href="<?php echo base_url();?>">Dashboard </a></li>
     <li class="breadcrumb-item active" aria-current="page">Student Detail</li>
  </ol>
</nav>

<div class="row">
	<div class="col-sm-1"></div>
	<div class="col-sm-3" style="">
		<div>Student Name</div>
		<div>Father Name</div>
		<div>DOB</div>
		<div>Email</div>
		<div>Phone</div>
		<div>Address</div>
		<div>City</div>
		<div>State</div>
		<div>Class</div>
		<div>Marks</div>
		<div>Enroll Date</div>
	</div>
	<div class="col-sm-5" style="background-color: #dcdcdc">
		<div><?php echo $abc['studentname']?></div>
		<div><?php echo $abc['fathername']?></div>
		<div><?php echo $abc['dob']?></div>
		<div><?php echo $abc['email']?></div>
		<div><?php echo $abc['phone']?></div>
		<div><?php echo $abc['address']?></div>
		<div><?php echo $abc['city']?></div>
		<div><?php echo $abc['state']?></div>
		<div><?php echo $abc['class']?></div>
		<div><?php echo $abc['marks']?></div>
		<div><?php echo $abc['created_at']?></div>
	</div>
	<div class="col-sm-1"></div>


		
	
</div>
</div>