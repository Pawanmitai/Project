<?php include('includes/header.php');?>
<h1 class="text-primary">Update Student Records</small></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
     <li class="breadcrumb-item" aria-current="page"><a href="<?php echo base_url();?>">Dashboard </a></li>
     <li class="breadcrumb-item active" aria-current="page">Edit Student</li>
  </ol>
</nav>

<div class="row">
	<div class="col-sm-3"></div>
<div class="col-sm-6">
	<?php if($this->session->flashdata('notsubmitted'))
	{ ?>
	<div class="alert alert-warning">
		<?php echo $this->session->flashdata('notsubmitted'); ?>
	</div>
<?php } ?>
		
	<form enctype="multipart/form-data" method="POST" action="<?php echo base_url('student/edit');?>">
		<div class="form-group">
		    <label for="name">Student Name</label>
		    <input name="studentname" type="text" class="form-control" pattern="[a-zA-Z ]{3,30}" value="<?php echo $students['studentname']?>" required="">
	  	</div>
	  	<div class="form-group">
		    <label for="eamil">Email</label>
		    <input name="email" type="text" value="<?php echo $students['email']?>"  class="form-control" pattern="^[A-Z0-9._%+-]{3,30}+@[A-Z0-9.-]{2,10}+\.[A-Z]{2,4}$" readonly  required="">
	  	</div>
	  	<div class="form-group">
		    <label for="pcontact">Phone</label>
		    <input name="phone" type="text" value="<?php echo $students['phone']?>" class="form-control" id="pcontact" pattern="[0-9]{10}"  required="">
	  	</div>
	  	<div class="form-group">
		    <label for="roll">DOB</label>
		    <input name="dob" type="date" value="<?php echo $students['dob']?>" class="form-control" pattern=""  required="">
	  	</div>
	  	<div class="form-group">
		    <label for="roll">Father Name</label>
		    <input name="fathername" type="text" value="<?php echo $students['fathername']?>" class="form-control" pattern="[a-zA-Z ]{2,30}"  required="">
	  	</div>
	  	<div class="form-group">
		    <label for="address">Address</label>
		    <input name="address" type="text" value="<?php echo $students['address']?>" pattern="[a-zA-Z0-9_./\ ]" class="form-control" id="address" required="">
	  	</div>
	  		<div class="form-group">
		    <label for="address">City</label>
		    <input name="city" type="text" value="<?php echo $students['city']?>" class="form-control" id="address" required="">
	  	</div>
	  		<div class="form-group">
		    <label for="address">State</label>
		    <input name="state" type="text" value="<?php echo $students['state']?>" pattern="[a-zA-Z ]{3,30}" class="form-control" id="address" required="">
	  	</div>
	  		<div class="form-group">
		    <label for="address">PIN</label>
		    <input name="pin" type="text" value="<?php echo $students['pin']?>" pattern="[0-9]{6}" class="form-control"  required="">
	  	</div>
	  	<div class="form-group">
		    <label for="class">Class Opted</label>
		    <select name="class" required aria-required="true" class="form-control" >
		    	<option value="<?php echo $students['class']?>"><?php echo $students['class']?></option>
		    	<option value="5th">5th</option>
		    	<option value="6th">6th</option>
		    	<option value="7th">7th</option>
		    	<option value="8th">8th</option>
		    	<option value="9th">9th</option>
		    	<option value="10th">10th</option>
		    </select>
	  	</div>
	  	<div class="form-group">
		    <label for="pcontact">Marks</label>
		    <input name="marks" value="<?php echo $students['marks']?>" type="text" class="form-control"  pattern="[0-9.%]{1,6}"  required="">
	  	</div>
	  	
	  	<div class="form-group text-center">
	  		<input type="hidden" name="id" value="<?php echo $students['id']?>">
		    <input name="submit" type="submit" class="btn btn-danger" value="Update Student">
	  	</div>
	 </form>
</div>
</div>