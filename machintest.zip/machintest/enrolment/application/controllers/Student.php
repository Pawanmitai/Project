<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

	
	public function index()
	{
		$this->load->model('Studentpage');


		$config=[
			'base_url'=> base_url().'student/index/',
			'per_page'=>5,
			'total_rows'=>$this->Studentpage->countrows(),
		];
		

		$this->pagination->initialize($config);
		
		$data['students']=$this->Studentpage->view($config['per_page'],$this->uri->segment(3));
		$this->load->view('index',$data);
	}

	public function addnewstudent()
	{
			
			 if($this->input->post('submit'))
			{

				$this->load->library('form_validation');
				$this->form_validation->set_rules('email', 'Email', 'required|is_unique[enrollment.email]');
				$this->form_validation->set_rules('phone', 'Phone', 'required|is_unique[enrollment.phone]');
				if($this->form_validation->run() == FALSE)
				{
					$this->session->set_flashdata('notsubmitted','Email and Phone no is already Exits');
					$this->load->view('addstudent');
				}
				else
				{
					$data=$_POST;
					unset($data['submit']);
					$this->load->model('Studentpage');
					$inserted=$this->Studentpage->addstudent($data);
					if($inserted)
					{
						$this->session->set_flashdata('record','Inserted');
						require redirect(base_url());
					}
				}
			}
		
			else
			{

				$this->load->view('addstudent');
			}
		
	}

	public function edit()
	{

				if($this->input->post('submit'))
				{

					$this->load->library('form_validation');
					//$this->form_validation->set_rules('email', 'Email', 'required|is_unique[enrollment.email]');
					//$this->form_validation->set_rules('phone', 'Phone', 'required|is_unique[enrollment.phone]');
					if($this->form_validation->run() == True)
					{
						$this->session->set_flashdata('notsubmitted','Not Updated');
						$this->load->view('editstudents');
					}
					else
					{
						$data=$_POST;
						$id=$data['id'];
						unset($data['id']);
						unset($data['submit']);
						$this->load->model('Studentpage');
						$inserted=$this->Studentpage->edit($data,$id);
						if($inserted)
						{
							$this->session->set_flashdata('record','Updated');
							require redirect(base_url());
						}
					}
				}
				
		else
		{
			$id=$this->input->get('id');
			$this->load->model('Studentpage');
			$data['students']=$this->Studentpage->recordview($id);
			$this->load->view('editstudents',$data);
		}
		
	}

	public function deleterecord()
	{
		$id=$this->input->get('id');
		$this->load->model('Studentpage');
		$deleted=$this->Studentpage->delete($id);
		if($deleted)
		{
			redirect(base_url());
		}
	}

	public function view_all()
	{
		$id=$this->input->get('id');
		$this->load->model('Studentpage');
		$data['abc']=$this->Studentpage->view_all($id);
		$this->load->view('viewstudents',$data);
	}

	public function singlerecord()
	{
			$id=$this->input->post('id');
			$this->load->model('Studentpage');
			$query=$this->Studentpage->recordview($id);
			echo json_encode($query);

	}

}
